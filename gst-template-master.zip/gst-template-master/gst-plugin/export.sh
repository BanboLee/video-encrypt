#!/bin/bash
export GST_PLUGIN_PATH_1_0=$GST_PLUGIN_PATH_1_0:$(pwd)/build/lib/gstreamer-1.0/
